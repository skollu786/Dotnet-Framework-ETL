﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ChoETL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Dynamic;
using Moq;

namespace ChoETL.Tests
{
    [TestClass()]
    public class ChoETLSQLiteTests
    {
        [TestMethod()]
        public void StageOnSQLiteTest()
        {
            var sqlClass = new Mock<SqlConnectClass>();
            ChoETLSQLite.sqlConnectClass = new Mock<SqlConnectClass>().Object;
            sqlClass.Setup(x => x.GetSqlDetail(It.IsAny<List<Item>>(), It.IsAny<ChoETLSqliteSettings>(), null)).Returns(Enumerable.Empty<Item>().AsQueryable());
            var items = new List<Item>
            {
                new Item { Id = 1, Name = "Tom" },
                new Item { Id = 2, Name = "Mark" },
                new Item { Id = 3, Name = "Sam" },
            };
            var result = ChoETLSQLite.StageOnSQLite(items, null);

            Assert.IsTrue(result.Count() == 0);
        }
    }

    public class Item
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}