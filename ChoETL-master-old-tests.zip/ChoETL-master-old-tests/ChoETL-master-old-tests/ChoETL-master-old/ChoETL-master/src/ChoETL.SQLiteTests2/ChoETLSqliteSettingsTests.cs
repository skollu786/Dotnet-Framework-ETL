﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ChoETL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChoETL.Tests
{
    [TestClass()]
    public class ChoETLSqliteSettingsTests
    {
        [TestMethod()]
        public void GetDatabaseFilePathShouldReturnLocalDBWhenConnectStringPathIsEmpty()
        {            
            var result = new ChoETLSqliteSettings() { ConnectionString = "" }.GetDatabaseFilePath();
            Assert.IsTrue(result == "local.db");

        }

        [TestMethod()]
        public void GetConnectionStringShouldReturnLocalDBWhenConnectStringPathIsEmpty()
        {
            var result = new ChoETLSqliteSettings() { ConnectionString = "" }.GetConnectionString();
            Assert.IsTrue(result == "DataSource=local.db");

        }
    }
}