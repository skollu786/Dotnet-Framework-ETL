﻿using ChoETL;

//[assembly: ChoAssemblyBetaVersion("beta1")]
